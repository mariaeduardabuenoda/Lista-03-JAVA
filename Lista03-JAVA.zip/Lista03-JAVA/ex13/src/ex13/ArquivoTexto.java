/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex13;

/**
 *
 * @author mariaeduardabuenodasilva
 */
public class ArquivoTexto implements Armazenavel {

    

    @Override
    public void salvar() {
        
        System.out.println("O arquivo de texto esta salvo.");
    }

    @Override
    public void carregar() {
        System.out.println("O arquivo de texto esta carregado.");
    }
    
}
