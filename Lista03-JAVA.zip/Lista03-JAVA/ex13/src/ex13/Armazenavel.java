/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex13;

/**
 *
 * @author mariaeduardabuenodasilva
 */
public interface  Armazenavel {
    
    
    //Métodos
    public void salvar();
    public void carregar();
    
}
