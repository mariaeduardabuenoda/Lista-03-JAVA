/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex13;

/**
 *
 * @author mariaeduardabuenodasilva
 */
public class BancoDeDados implements Armazenavel {

    

    @Override
    public void salvar() {
        System.out.println("O banco de dados esta salvo.");
    }

    @Override
    public void carregar() {
        System.out.println("O banco de dados esta carregado.");
    }
    
}
