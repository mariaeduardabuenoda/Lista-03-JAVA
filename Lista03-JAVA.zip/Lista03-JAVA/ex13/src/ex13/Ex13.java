/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ex13;

/**
 *
 * @author mariaeduardabuenodasilva
 */
public class Ex13 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Armazenavel  arquivoTexto = new ArquivoTexto();
        Armazenavel  bancoDeDados = new BancoDeDados();

        arquivoTexto.carregar();
        bancoDeDados.carregar();
        
        arquivoTexto.salvar();
        bancoDeDados.salvar();
        

    }
    
}
