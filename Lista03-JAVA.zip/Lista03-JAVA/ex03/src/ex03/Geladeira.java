/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex03;

/**
 *
 * @author mariaeduardabuenodasilva
 */
public class Geladeira implements Eletrodomestico {

    @Override
    public void ligar() {
        System.out.println("A geladeira esta ligada!");
    }

    @Override
    public void desligar() {
        System.out.println("A geladeira esta desligada");
    }

    
    
}
