/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ex03;

/**
 *
 * @author mariaeduardabuenodasilva
 */
public class Ex03 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Eletrodomestico geladeira = new Geladeira();
        Eletrodomestico televisao = new Televisao();
        
        geladeira.desligar();
        geladeira.ligar();
        
        televisao.desligar();
        televisao.ligar();
        
        //ex20
        Eletrodomestico microondas = new Microondas();
        microondas.verificarEstado();
        
     

    }
    
}
