/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex03;

/**
 *
 * @author mariaeduardabuenodasilva
 */
public interface  Eletrodomestico {
    
    public void ligar();
    public void desligar();
    
    //ex20
    public default void verificarEstado(){
        System.out.println("O microandas ja vai apitar!");
    }
    
}
