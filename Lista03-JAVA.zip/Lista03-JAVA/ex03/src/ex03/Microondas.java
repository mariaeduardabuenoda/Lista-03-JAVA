/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex03;

/**
 *
 * @author mariaeduardabuenodasilva
 */
//ex20
public class Microondas implements Eletrodomestico {

    public Microondas() {
    }

   

    @Override
    public void verificarEstado() {
        Eletrodomestico.super.verificarEstado(); 
    }

    @Override
    public void ligar() {
        System.out.println("O microondas  esta ligado!");
    }

    @Override
    public void desligar() {
        System.out.println("O microondas  esta desligado!");
    }
    
}
