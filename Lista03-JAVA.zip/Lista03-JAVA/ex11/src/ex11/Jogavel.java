/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex11;

/**
 *
 * @author mariaeduardabuenodasilva
 */
public interface  Jogavel {
    
    public void iniciarJogo();
    
}
