/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex11;

/**
 *
 * @author mariaeduardabuenodasilva
 */
public class Futebol implements Jogavel {

   

    @Override
    public void iniciarJogo() {
        System.out.println("O Futebol esta comecando!");
    }
    
}
