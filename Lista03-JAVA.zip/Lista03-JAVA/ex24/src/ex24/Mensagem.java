/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex24;

/**
 *
 * @author mariaeduardabuenodasilva
 */
public interface Mensagem {
    
    public  void mensagem();
    
}
