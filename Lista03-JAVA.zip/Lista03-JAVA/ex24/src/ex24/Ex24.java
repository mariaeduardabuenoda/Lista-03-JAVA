/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ex24;

/**
 *
 * @author mariaeduardabuenodasilva
 */
public class Ex24 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Mensagem user = new Usuario();
        user.mensagem();

    }
    
}
