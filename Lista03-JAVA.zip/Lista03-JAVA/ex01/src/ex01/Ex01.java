/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ex01;

/**
 *
 * @author mariaeduardabuenodasilva
 */
public class Ex01 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        IVeiculo meuCarro= new Carro();
        IVeiculo minhaMoto = new Moto();
        
        meuCarro.acelerar();
        minhaMoto.acelerar();
    }
    
}
