/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex01;

/**
 *
 * @author mariaeduardabuenodasilva
 */
public class Moto implements IVeiculo {

   

    @Override
    public void acelerar() {
        System.out.println("A moto esta acelerando!!");    }
    
}
