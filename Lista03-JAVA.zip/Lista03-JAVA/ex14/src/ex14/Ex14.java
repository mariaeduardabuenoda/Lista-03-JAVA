/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ex14;

/**
 *
 * @author mariaeduardabuenodasilva
 */
public class Ex14 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Sensores sensorDeTemperatura = new SensorDeTemperatura();
        Sensores sensorDePressao = new SensorDePressao();
        
        sensorDeTemperatura.medirTemperatura();
        sensorDePressao.medirTemperatura();

    }
    
}
