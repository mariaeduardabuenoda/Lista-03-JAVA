/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex14;

/**
 *
 * @author mariaeduardabuenodasilva
 */
public interface  Sensores {
    
    public void medirTemperatura();
    
}
