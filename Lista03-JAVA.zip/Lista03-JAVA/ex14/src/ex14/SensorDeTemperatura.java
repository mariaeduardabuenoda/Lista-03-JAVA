/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex14;

/**
 *
 * @author mariaeduardabuenodasilva
 */
public class SensorDeTemperatura implements Sensores {

    @Override
    public void medirTemperatura() {
        System.out.println("Ha alguma pessoa ou ser vivo na area!!!");
    }

    
    
}
