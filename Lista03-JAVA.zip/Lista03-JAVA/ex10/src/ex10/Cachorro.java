/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex10;

/**
 *
 * @author mariaeduardabuenodasilva
 */
//ex16
public class Cachorro implements Animal {

    

    @Override
    public void dormir() {
        Animal.super.dormir(); 
    }

    @Override
    public void comer() {
        System.out.println("O cachorro esta comendo carne!");
    }
    
}
