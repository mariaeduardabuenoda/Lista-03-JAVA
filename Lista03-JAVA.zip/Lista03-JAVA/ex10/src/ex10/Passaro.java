/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex10;

/**
 *
 * @author mariaeduardabuenodasilva
 */
public class Passaro implements Animal , Voador{

    

    @Override
    public void comer() {
        System.out.println("O passaro esta comendo alpiste!");
    }

    @Override
    public void voar() {

        System.out.println("O passaro esta voando alto!");
    }
    
}
