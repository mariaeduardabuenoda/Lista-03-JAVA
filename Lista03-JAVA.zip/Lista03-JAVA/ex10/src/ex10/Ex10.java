/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ex10;

/**
 *
 * @author mariaeduardabuenodasilva
 */
public class Ex10 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Passaro myPassaro = new Passaro();
        
        //ex16
        Animal cachorro = new Cachorro();
        
        myPassaro.comer();
        myPassaro.voar();
        
        //ex16
        cachorro.dormir();

        
    }
    
}
