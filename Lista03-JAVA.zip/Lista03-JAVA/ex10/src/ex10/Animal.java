/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex10;

/**
 *
 * @author mariaeduardabuenodasilva
 */
public interface Animal {
    
    public void comer();
    
    //ex16
    default void dormir(){
        System.out.println("Zzz...");
    }
    
}
