/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex4;

/**
 *
 * @author mariaeduardabuenodasilva
 */
public class Quadrado implements FormaGeometrica {

   int area = 0;
   int lado = 4;

    @Override
    public void calcularArea() {
        area = lado * lado;
        System.out.println("O calculo da area do quadrado é: " + area);



    }
    
}
