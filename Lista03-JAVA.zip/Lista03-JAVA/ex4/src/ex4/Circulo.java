/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex4;

/**
 *
 * @author mariaeduardabuenodasilva
 */
public class Circulo implements FormaGeometrica {

    double area = 0.00;
    double PI = 3.14;
    int raio = 4;

    @Override
    public void calcularArea() {
        
        area = PI * raio * raio;
        System.out.println("O calculo da area do circulo é: " + area);
    }
    
}
