/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ex4;

/**
 *
 * @author mariaeduardabuenodasilva
 */
public class Ex4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        FormaGeometrica quadrado = new Quadrado();
        FormaGeometrica circulo = new Circulo();
        
        quadrado.calcularArea();
        circulo.calcularArea();


    }
    
}
