/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex25;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

/**
 *
 * @author mariaeduardabuenodasilva
 */
public class Relogio implements Horario {

    

    @Override
    public String getHoraAtual() {
        
        LocalTime agora = LocalTime.now();
        
        DateTimeFormatter formatador = DateTimeFormatter.ofPattern("HH:mm:ss");
        
        
        return agora.format(formatador);
        
        
        
        
        

    }
    
}
