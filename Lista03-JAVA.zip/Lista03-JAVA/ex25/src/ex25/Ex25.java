/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ex25;

/**
 *
 * @author mariaeduardabuenodasilva
 */
public class Ex25 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        Horario relogio = new Relogio();
        System.out.println("Que horas são?");
        System.out.println("Agora são exatamente: " + relogio.getHoraAtual());
    }
    
}
