/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex12;

/**
 *
 * @author mariaeduardabuenodasilva
 */
public class CartaoCredito implements Pagamento {

    

    @Override
    public void pagar() {
        System.out.println("O pagamento foi pago com o cartão de crédito.");
    }
    
     //ex18
    @Override
    public void cancelarPagamento(){
        Pagamento.super.cancelarPagamento();
    }
}
