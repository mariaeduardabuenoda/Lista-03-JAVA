/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex12;

/**
 *
 * @author mariaeduardabuenodasilva
 */
public interface  Pagamento {
    
    public void pagar();
    
    //ex18
    public default void cancelarPagamento(){
        System.out.println("O pagamentos foi cancelado!");
    }
    
}
