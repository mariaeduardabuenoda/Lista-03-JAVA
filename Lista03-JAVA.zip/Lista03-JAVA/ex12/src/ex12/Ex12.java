/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ex12;

/**
 *
 * @author mariaeduardabuenodasilva
 */
public class Ex12 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Pagamento myCartaoCredito = new  CartaoCredito();
        Pagamento myBoleto = new Boleto();
        Pagamento pix = new PIX();
        
        myCartaoCredito.pagar();
        myCartaoCredito.cancelarPagamento();
        myBoleto.pagar();
         //ex18
        pix.pagar();
        pix.cancelarPagamento();

    }
    
}
