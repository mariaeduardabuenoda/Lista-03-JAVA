/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex21;

/**
 *
 * @author mariaeduardabuenodasilva
 */
public class Temperatura implements Conversor {

    
   

    @Override
    public  void converter(){
        double C =37.00;
      double resultado = C * 1.8 + 32;

        System.out.println("O resultado de" + C +" graus Celcius para Fahrenheit é...." + resultado);
        
    
 }
}