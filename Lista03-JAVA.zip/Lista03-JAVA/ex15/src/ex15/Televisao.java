/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex15;

/**
 *
 * @author mariaeduardabuenodasilva
 */
public class Televisao implements ControleRemoto {

    @Override
    public void aumentarVolume() {
        System.out.println("O volume da televisão esta aumentando!");
    }

    @Override
    public void diminuirVolume() {
        System.out.println("O volume da televisão esta diminuindo!");
    }

   
    
}
