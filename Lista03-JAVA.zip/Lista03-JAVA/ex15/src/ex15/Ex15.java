/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ex15;

/**
 *
 * @author mariaeduardabuenodasilva
 */
public class Ex15 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Televisao TV = new Televisao();
        
        TV.aumentarVolume();
        TV.diminuirVolume();
    }
    
}
