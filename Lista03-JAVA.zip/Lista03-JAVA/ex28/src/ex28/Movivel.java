/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex28;

/**
 *
 * @author mariaeduardabuenodasilva
 */
public interface  Movivel {
    
    public void moverParaFrente();
    public void moverParaTras();
    
}
