/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex28;

/**
 *
 * @author mariaeduardabuenodasilva
 */
public class Robo implements Movivel {

    @Override
    public void moverParaFrente() {
        System.out.println("O robo se move para frente!");    }

    @Override
    public void moverParaTras() {
        System.out.println("O robo se move para trás!");    }

    
}
