/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex23;

/**
 *
 * @author mariaeduardabuenodasilva
 */
public class Matematica implements Utilitario{

    public Matematica() {
    }

    @Override
    public void calcFatorial() {
    int resultado = 0;
      int  fatNum = 5;
   
   resultado = 5 * 4 *3 * 2 * 1;   
    
        System.out.println("O fatorial do numero " + fatNum +" é.... " + resultado );
    
    }
    
}
