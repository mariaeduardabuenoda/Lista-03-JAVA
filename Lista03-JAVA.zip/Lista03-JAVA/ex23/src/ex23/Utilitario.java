/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex23;

/**
 *
 * @author mariaeduardabuenodasilva
 */
public interface  Utilitario {
    
    
     public void calcFatorial();
    
    
}
