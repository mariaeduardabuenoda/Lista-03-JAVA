/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ex02;

/**
 *
 * @author mariaeduardabuenodasilva
 */
public class Ex02 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        InstrumentoMusical violao = new Violao();
        InstrumentoMusical piano = new Piano();
        
        violao.Tocar();
        piano.Tocar();

    }
    
}
