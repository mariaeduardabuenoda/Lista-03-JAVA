/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex02;

/**
 *
 * @author mariaeduardabuenodasilva
 */
public class Piano implements InstrumentoMusical {

    @Override
    public void Tocar(){
        System.out.println("O piano esta tocando!");
    }
}