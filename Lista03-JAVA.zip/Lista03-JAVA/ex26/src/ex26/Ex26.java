/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ex26;

/**
 *
 * @author mariaeduardabuenodasilva
 */
public class Ex26 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Transmissivel myYoutube = new Youtube();
        Transmissivel myTwitch = new Twitch();

        myYoutube.iniciarTransmissao();
        myTwitch.iniciarTransmissao();
        
        myTwitch.finalizarTransmissao();
        myYoutube.finalizarTransmissao();
        
    }
    
}
