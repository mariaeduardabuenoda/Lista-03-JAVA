/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex26;

/**
 *
 * @author mariaeduardabuenodasilva
 */
public class Youtube implements Transmissivel {

    

    @Override
    public void iniciarTransmissao() {
        System.out.println("Comecou a transmissão no Youtube!");    }

    @Override
    public void finalizarTransmissao() {
        System.out.println("Terminou a transmissão no Youtube!");    
    }
    
}
