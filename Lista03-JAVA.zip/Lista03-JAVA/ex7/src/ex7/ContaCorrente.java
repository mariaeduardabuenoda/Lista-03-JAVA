/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex7;

/**
 *
 * @author mariaeduardabuenodasilva
 */
public class ContaCorrente implements Banco {

    private String nome;
    public ContaCorrente(String nome) {
        this.nome = nome;
    }

    @Override
    public void sacar() {
        System.out.println( nome +", sacou R$ 4.000.00");

    }

    @Override
    public void depositar() {
        System.out.println( nome +", depositou R$ 8.000.00");
    }

    @Override
    public void verSaldo() {
                System.out.println( nome +", seu saldo ficou... R$ 4.000.00");

    }
    
}
