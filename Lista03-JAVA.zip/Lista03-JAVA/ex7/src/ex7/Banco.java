/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex7;

/**
 *
 * @author mariaeduardabuenodasilva
 */
public interface  Banco {
    
    public void sacar();
    public void depositar();
    public void verSaldo();
    
}
