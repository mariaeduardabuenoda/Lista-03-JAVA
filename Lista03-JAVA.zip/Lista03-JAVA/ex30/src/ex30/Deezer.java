/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex30;

/**
 *
 * @author mariaeduardabuenodasilva
 */
public class Deezer implements Musica {

  

    @Override
    public void play() {
    
        System.out.println("A musica no Deezer está em play!");
    }

    @Override
    public void pause() {
        System.out.println("A musica no Deezer está pausada!");
    }

    @Override
    public void stop() {
        System.out.println("A musica no Deezer está parada!");
    }
    
}
