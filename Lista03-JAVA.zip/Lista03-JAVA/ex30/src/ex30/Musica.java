/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex30;

/**
 *
 * @author mariaeduardabuenodasilva
 */
public interface  Musica {
    
    
    public void play();
    public void pause();
    public void stop();
}
