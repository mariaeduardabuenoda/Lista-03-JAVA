/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ex30;

/**
 *
 * @author mariaeduardabuenodasilva
 */
public class Ex30 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
      Musica   spotify = new Spotify();
      Musica   deezer  = new Deezer();
      
      spotify.play();
      deezer.pause();
      spotify.stop();


    }
    
}
