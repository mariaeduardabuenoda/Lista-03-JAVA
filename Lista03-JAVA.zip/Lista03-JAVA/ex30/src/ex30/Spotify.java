/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex30;

/**
 *
 * @author mariaeduardabuenodasilva
 */
public class Spotify implements Musica {

    

    @Override
    public void play() {
        System.out.println("A musica no Spotify está em play!");
    }

    @Override
    public void pause() {
        System.out.println("A musica no Spotify está pausada!");
    }

    @Override
    public void stop() {
        System.out.println("A musica no Spotify está parada!");
    }
    
}
