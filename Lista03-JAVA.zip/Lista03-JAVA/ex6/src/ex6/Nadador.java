/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex6;

/**
 *
 * @author mariaeduardabuenodasilva
 */
public interface  Nadador {
    public void nadar();
    
}
