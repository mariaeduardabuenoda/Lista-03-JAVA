/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex6;

/**
 *
 * @author mariaeduardabuenodasilva
 */
public class Triatleta implements Nadador ,Corredor {

    private final String nome;

     Triatleta(String nome) {
        this.nome = nome;
    }

    

    
    
    @Override
    public void nadar() {
        System.out.println(nome + " está nadando.");
    }

    @Override
    public void correr() {
        System.out.println(nome + " está correndo.");
    }
    
    
    void realizarTriatlo() {
      System.out.println("--- Iniciando Triatlo ---");
        nadar();
        correr();
        System.out.println(nome + " finalizou o triatlo!");
    }

    
}
