/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex9;

/**
 *
 * @author mariaeduardabuenodasilva
 */
public class Imagem implements Imprimivel{

   

    @Override
    public void imprimir() {
        System.out.println("Imprimindo imagem...");
    }
    
}
