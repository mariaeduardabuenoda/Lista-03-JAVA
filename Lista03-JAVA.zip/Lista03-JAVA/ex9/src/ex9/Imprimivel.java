/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex9;

/**
 *
 * @author mariaeduardabuenodasilva
 */
public interface  Imprimivel {
    public void imprimir();
    
    //ex17
    public default void mostrarNoMonitor(){
        System.out.println("Exibindo no monitor");
    } 
    
}
