/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex9;

/**
 *
 * @author mariaeduardabuenodasilva
 */
public class Documento implements Imprimivel{

    

    @Override
    public void imprimir() {
        System.out.println("Imprimindo documento...");
        
    }
    
    //ex17
        @Override

        public void mostrarNoMonitor(){
            Imprimivel.super.mostrarNoMonitor();
        }
    
}
