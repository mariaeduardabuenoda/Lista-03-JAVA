/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ex9;

/**
 *
 * @author mariaeduardabuenodasilva
 */
public class Ex9 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Imprimivel myDocumento = new Documento();
        Imprimivel myImagem = new Imagem();
        
        myDocumento.imprimir();
        myImagem.imprimir();
        
        //ex17
        myDocumento.mostrarNoMonitor();
    }
    
}
