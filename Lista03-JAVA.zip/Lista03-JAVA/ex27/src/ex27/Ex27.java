/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ex27;

/**
 *
 * @author mariaeduardabuenodasilva
 */
public class Ex27 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Autenticavel  user = new UsuarioSistema();
        Autenticavel admin = new Administrador();
        
        user.login();
        admin.login();
        
        user.logout();
        admin.logout();


    }
    
}
