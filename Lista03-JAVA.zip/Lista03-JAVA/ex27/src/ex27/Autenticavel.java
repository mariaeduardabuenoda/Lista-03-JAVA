/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex27;

/**
 *
 * @author mariaeduardabuenodasilva
 */
public interface  Autenticavel {
    
    public void login() ;
    public void logout();
    
}
