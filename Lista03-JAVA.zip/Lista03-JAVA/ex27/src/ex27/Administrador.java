/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex27;

/**
 *
 * @author mariaeduardabuenodasilva
 */
public class Administrador implements Autenticavel {

    
    @Override
    public void login() {
        System.out.println("O administrador do sistema  esta logado!");    }

    @Override
    public void logout() {
        System.out.println("O administrador do sistema saiu!");    }
    
}
