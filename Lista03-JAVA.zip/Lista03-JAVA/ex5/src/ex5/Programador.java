/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex5;

/**
 *
 * @author mariaeduardabuenodasilva
 */
public class Programador implements Funcionario {

 
    @Override
    public void calcularSalario() {
        System.out.println("O salário do programador é : 2.500.00");

    }
    
}
