/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ex5;

/**
 *
 * @author mariaeduardabuenodasilva
 */
public class Ex5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Funcionario  gerente = new Gerente();
        Funcionario  programador = new Programador();
        
        gerente.calcularSalario();
        programador.calcularSalario();
    }
    
}
