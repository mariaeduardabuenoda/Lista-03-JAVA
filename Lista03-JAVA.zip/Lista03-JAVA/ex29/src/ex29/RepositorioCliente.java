/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex29;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author mariaeduardabuenodasilva
 */
import java.util.ArrayList;
import java.util.List;

public class RepositorioCliente implements Repositorio<Cliente> {

    private List<Cliente> bancoDeDados = new ArrayList<>();

    @Override
    public void salvar(Cliente objeto) {
        bancoDeDados.add(objeto);
        System.out.println("Cliente " + objeto.getNome() + " salvo com sucesso!");
    }

    @Override
    public Cliente buscar(int id) {
        for (Cliente c : bancoDeDados) {
            if (c.getId() == id) {
                return c;
            }
        }
        System.out.println("Cliente com ID " + id + " não encontrado.");
        return null;
    }
}