/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex29;

/**
 *
 * @author mariaeduardabuenodasilva
 */
class Cliente {
    private int id;
    private String nome;
    
    
    public Cliente(int id, String nome){
        this.id = id;
        this.nome = nome;
        
    }
    
    public int getId(){
        return id;
    }
    public String getNome(){
        return nome;
    }
    
    @Override
    public String toString(){
        return "Cliente [ID= " + id + ", Nome= " + nome +"]";
    }
}
