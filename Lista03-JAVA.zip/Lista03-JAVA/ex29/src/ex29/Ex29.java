/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ex29;

/**
 *
 * @author mariaeduardabuenodasilva
 */
public class Ex29 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Repositorio<Cliente>  repositorio = (Repositorio<Cliente>) new RepositorioCliente();
        
        repositorio.salvar(new Cliente(1, "Maria "));
        repositorio.salvar(new Cliente (2, "Ana"));
        
        
        Cliente encontrado = repositorio.buscar(1);
        if(encontrado != null){
        System.out.println("resultado da busca: " + encontrado);
        }

    }
    
}
