/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex29;

/**
 *
 * @author mariaeduardabuenodasilva
 */
public interface Repositorio<T> {
    
    
    public void salvar(T objeto);
    T buscar(int id);
}
