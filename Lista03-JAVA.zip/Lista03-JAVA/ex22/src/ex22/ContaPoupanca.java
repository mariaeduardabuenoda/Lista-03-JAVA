/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex22;

/**
 *
 * @author mariaeduardabuenodasilva
 */
public class ContaPoupanca  implements Banco{

    double taxa = 25.35;
    @Override
    public void taxaJuros() {
        System.out.println("A taxa de juros atual é ...." + taxa);    }
    
}
