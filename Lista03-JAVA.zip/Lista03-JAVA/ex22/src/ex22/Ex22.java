/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ex22;

/**
 *
 * @author mariaeduardabuenodasilva
 */
public class Ex22 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        ContaPoupanca   contaPoupanca =  new ContaPoupanca();
        contaPoupanca.taxaJuros();
    }
    
}
