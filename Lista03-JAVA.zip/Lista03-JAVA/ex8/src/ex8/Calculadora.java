/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex8;

/**
 *
 * @author mariaeduardabuenodasilva
 */
public class Calculadora implements OperacoesMatematicas {

    
    
    int resultado = 0;

    @Override
    public void somar() {
        
        resultado = 2 + 2;
        System.out.println("O resultado da soma é: " + resultado);
        

    }

    @Override
    public void subtrair() {
        resultado = 8 - 4;
        System.out.println("O resultado da subtrcao é: " + resultado);

    }

    @Override
    public void multiplicar() {
        resultado = 5 * 5;
        System.out.println("O resultado da multiplicacão é: " + resultado);
    }

    @Override
    public void dividir() {
        resultado = 24 / 2;
        System.out.println("o resultado da divisão é: " + resultado);

    }
    
}
