/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ex8;

/**
 *
 * @author mariaeduardabuenodasilva
 */
public class Ex8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        OperacoesMatematicas calculadora = new Calculadora();

        calculadora.somar();
        calculadora.subtrair();
        calculadora.multiplicar();
        calculadora.dividir();
        
        
        //ex19
        OperacoesMatematicas calculadoraCientifica = new CalculadoraCientifica();
        calculadoraCientifica.potencia();
    }
    
}
