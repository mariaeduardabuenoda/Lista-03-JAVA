/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex8;

/**
 *
 * @author mariaeduardabuenodasilva
 */
public interface  OperacoesMatematicas {
    
    public void somar();
    public void subtrair();
    public void multiplicar();
    public void dividir();
    
    //ex19
    public  default void  potencia(){
        System.out.println("A potencia será calculada....");   
 }
}